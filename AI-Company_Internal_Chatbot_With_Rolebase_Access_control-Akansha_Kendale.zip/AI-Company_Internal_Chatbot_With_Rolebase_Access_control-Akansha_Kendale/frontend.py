import streamlit as st
import requests

API_URL = "http://127.0.0.1:8000"
if "token" not in st.session_state: st.session_state.token = None

if not st.session_state.token:
    st.title("Fintech Portal")
    t1, t2 = st.tabs(["Login", "Register"])
    with t1:
        u, p = st.text_input("User"), st.text_input("Pass", type="password")
        if st.button("Login"):
            res = requests.post(f"{API_URL}/login", json={"username": u, "password": p})
            if res.status_code == 200:
                st.session_state.token, st.session_state.role = res.json()["access_token"], res.json()["role"]
                st.rerun()
    with t2:
        ru, rp = st.text_input("New User"), st.text_input("New Pass", type="password")
        rr = st.selectbox("Role", ["finance", "hr", "c_level", "employees"])
        if st.button("Register"):
            requests.post(f"{API_URL}/register", json={"username": ru, "password": rp, "role": rr})
            st.success("Done!")
else:
    st.title(f"Assistant ({st.session_state.role.upper()})")
    if st.sidebar.button("Logout"): 
        st.session_state.token = None
        st.rerun()
    q = st.chat_input("Ask a question...")
    if q:
        res = requests.post(f"{API_URL}/chat", json={"query": q}, headers={"Authorization": f"Bearer {st.session_state.token}"})
        st.write(res.json()["answer"])
        st.caption(f"Source: {res.json()['sources']}")