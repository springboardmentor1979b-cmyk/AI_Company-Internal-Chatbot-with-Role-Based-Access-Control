import os
import pandas as pd
import nltk
from nltk.tokenize import word_tokenize
from sentence_transformers import SentenceTransformer
import chromadb

# Setup
nltk.download('punkt')
model = SentenceTransformer("all-MiniLM-L6-v2")
client = chromadb.PersistentClient(path="./company_chroma_db")
collection = client.get_or_create_collection(name="company_docs")

def clean_text(text):
    return " ".join(text.replace("\n", " ").replace("\t", " ").split())

def chunk_text(text, chunk_size=250):
    words = word_tokenize(text)
    return [" ".join(words[i:i+chunk_size]) for i in range(0, len(words), chunk_size)]

# Role Mapping
role_mapping = {
    "finance": ["finance_report.md", "quarterly_summary.csv"],
    "marketing": ["marketing_analysis.md", "campaign_data.csv"],
    "hr": ["employee_data.csv", "hr_policies.md", "hr_data.csv"],
    "engineering": ["tech_docs.md", "system_architecture.md"],
    "employees": ["general_handbook.md", "policies.md"],
    "c_level": "all" 
}

def assign_metadata(file_name, chunk):
    roles = []
    for role, files in role_mapping.items():
        if files == "all" or file_name in files:
            roles.append(role.lower()) # Force lowercase
    return {"source": file_name, "roles": ",".join(roles)}

print("Starting document ingestion...")
folder = "Fintech-data"
if not os.path.exists(folder):
    print(f"ERROR: Folder {folder} not found!")
else:
    for root, dirs, files in os.walk(folder):
        for file_name in files:
            file_path = os.path.join(root, file_name)
            text_content = ""
            if file_name.endswith(".md"):
                with open(file_path, "r", encoding="utf-8") as f:
                    text_content = f.read()
            elif file_name.endswith(".csv"):
                df = pd.read_csv(file_path)
                text_content = " ".join(df.astype(str).values.flatten())

            if text_content:
                chunks = chunk_text(clean_text(text_content))
                for i, chunk in enumerate(chunks):
                    metadata = assign_metadata(file_name, chunk)
                    embedding = model.encode(chunk).tolist()
                    collection.add(
                        ids=[f"{file_name}_{i}"], 
                        embeddings=[embedding], 
                        documents=[chunk], 
                        metadatas=[metadata]
                    )

print("SUCCESS: Database saved to ./company_chroma_db")