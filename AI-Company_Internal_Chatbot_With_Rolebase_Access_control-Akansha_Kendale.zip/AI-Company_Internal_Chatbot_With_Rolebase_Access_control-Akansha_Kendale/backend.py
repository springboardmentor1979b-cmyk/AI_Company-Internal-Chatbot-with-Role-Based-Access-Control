import os, jwt, datetime, json
from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
import chromadb
from sentence_transformers import SentenceTransformer

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

SECRET_KEY = "fintech_secret"
USER_FILE = "users_db.json"
model = SentenceTransformer("all-MiniLM-L6-v2")
client = chromadb.PersistentClient(path="./company_chroma_db")
collection = client.get_or_create_collection(name="company_docs")

class User(BaseModel):
    username: str
    password: str
    role: str = "employees"

class ChatRequest(BaseModel):
    query: str

def load_users():
    if os.path.exists(USER_FILE):
        with open(USER_FILE, "r") as f: return json.load(f)
    return {}

def save_users(users):
    with open(USER_FILE, "w") as f: json.dump(users, f)

@app.post("/register")
async def register(user: User):
    users = load_users()
    users[user.username] = {"password": user.password, "role": user.role.lower()}
    save_users(users)
    return {"message": "Success"}

@app.post("/login")
async def login(user: User):
    users = load_users()
    u = users.get(user.username)
    if not u or u["password"] != user.password: raise HTTPException(401)
    token = jwt.encode({
        "sub": user.username, 
        "role": u["role"], 
        "exp": datetime.datetime.utcnow() + datetime.timedelta(hours=24)
    }, SECRET_KEY, algorithm="HS256")
    return {"access_token": token, "role": u["role"]}

@app.post("/chat")
async def chat(request: ChatRequest, req: Request):
    try:
        auth_header = req.headers.get("Authorization")
        token = auth_header.split(" ")[1]
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        user_role = payload.get("role").lower()

        # Semantic Search
        query_emb = model.encode(request.query).tolist()
        results = collection.query(query_embeddings=[query_emb], n_results=3)
        
        valid_context, source_file = "", ""
        if results["documents"]:
            for i, doc in enumerate(results["documents"][0]):
                meta_roles = results["metadatas"][0][i]["roles"].lower().split(",")
                if user_role == "c_level" or user_role in meta_roles:
                    valid_context, source_file = doc, results["metadatas"][0][i]["source"]
                    break

        if not valid_context:
            return {"answer": f"Access Denied for role: {user_role}", "sources": []}
        
        return {"answer": f"According to internal records: {valid_context}", "sources": [source_file]}
    except Exception as e:
        print(f"Error: {e}")
        return {"answer": "Authentication or search error.", "sources": []}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)